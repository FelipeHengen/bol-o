import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bolão da Mega Sena',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<int> _numbers = [];

  void _generateNumbers() {
    final random = Random();
    final generatedNumbers = <int>{};

    / Gerando números usando while
    while (generatedNumbers.length < 6) {
      generatedNumbers.add(random.nextInt(60) + 1);
    }


    setState(() {
      _numbers = generatedNumbers.toList()..sort();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bolão da Mega Sena'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            if (_numbers.isEmpty)
              Text(
                'Clique no botão para gerar números',
                style: TextStyle(fontSize: 20),
              )
            else
              Column(
                children: [
                  Text(
                    'Números Sorteados:',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),

                  Container(
                    padding: EdgeInsets.all(16),
                    child: DataTable(
                      columns: [
                        DataColumn(label: Center(child: Text('Números'))),
                      ],
                      rows: _numbers.map((number) {
                        return DataRow(cells: [
                          DataCell(
                            Center(
                              child: Text(
                                '$number',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blueAccent,
                                ),
                              ),
                            ),
                          ),
                        ]);
                      }).toList(),
                    ),
                  ),
                ],
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _generateNumbers,
              child: Text('Gerar Números'),
            ),
          ],
        ),
      ),
    );
  }
}
