package com.example.bolao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
